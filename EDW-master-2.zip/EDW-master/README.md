# EDW
EDW Workshop 2021

How to run the file  ?

Step1: Download .zip file

Step2: extract and Upload all files to jupyter lab or any other prefered notebook environment.

Step3: Run EDW.ipynb
